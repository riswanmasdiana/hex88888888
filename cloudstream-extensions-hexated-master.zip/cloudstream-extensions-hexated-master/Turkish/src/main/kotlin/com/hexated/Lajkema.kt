package com.hexated

import com.lagradost.cloudstream3.extractors.XStreamCdn

class Lajkema : XStreamCdn() {
    override val name: String = "Lajkema"
    override val mainUrl: String = "https://lajkema.com"
}